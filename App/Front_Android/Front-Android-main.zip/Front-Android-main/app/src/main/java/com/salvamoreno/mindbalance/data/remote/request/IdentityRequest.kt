package com.salvamoreno.mindbalance.data.remote.request

data class IdentityRequest(
    val email: String,
    val dni: String
)