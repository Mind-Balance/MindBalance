package com.salvamoreno.mindbalance.data.remote.request

data class ChangePasswordRequest (
    val newPassword: String
)