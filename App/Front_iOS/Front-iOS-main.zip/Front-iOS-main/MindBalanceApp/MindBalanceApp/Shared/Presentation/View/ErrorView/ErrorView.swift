//
//  ErrorView.swift
//  MindBalanceApp
//
//  Created by Manuel Cazalla Colmenero on 24/4/24.
//

import SwiftUI

struct ErrorView: View {
    var body: some View {
        Text("Error!")
    }
}

#Preview {
    ErrorView()
}
